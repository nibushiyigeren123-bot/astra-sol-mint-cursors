# sol 薄荷绿 Windows 指针

此单角色包含32/48/64三档，每档17状态。

解压后运行：
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

在控制面板 → 鼠标 → 指针中选择 sol Mint 48px 并应用。

要直接应用：
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Character sol -Size 48 -Apply
```

恢复：运行同一脚本加 -Restore。

完整源码、预览、来源及其他角色：https://github.com/nibushiyigeren123-bot/astra-sol-mint-cursors
