# sol 薄荷绿 Windows 指针

此单角色包含32/48/64/128/256五档，每档17状态。

解压后双击 应用_sol_64px.cmd，或对应128px/256px快捷脚本。旧版问题已修复，64px现在为原来32px显示的两倍宽高。应用后逐项确认17个实际系统指针尺寸。

也可以运行：
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Character sol -Size 64 -Apply
```

单在控制面板里选择方案可能被Windows缩回默认大小，请使用上面的应用脚本。

恢复：运行同一脚本加 -Restore。

完整源码、预览、来源及其他角色：https://github.com/nibushiyigeren123-bot/astra-sol-mint-cursors
