# astra 薄荷绿 Windows 指针

此单角色包含32/48/64/128/256五档，每档17状态。v1.0.2：直接右键install.ps1选择使用PowerShell运行，默认应用本角色64px并核验全部17状态。

也可以双击 应用_Astra_64px.cmd，或对应32px/48px/128px/256px快捷脚本，共五份，每份安装并应用对应尺寸。旧版问题已修复，64px现在为原来32px显示的两倍宽高。应用后逐项确认17个实际系统指针尺寸。

也可以运行：
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Character astra -Size 64 -Apply
```

单在控制面板里选择方案可能被Windows缩回默认大小，请使用上面的应用脚本。

恢复：运行同一脚本加 -Restore。

完整源码、预览、来源及其他角色：https://github.com/nibushiyigeren123-bot/astra-sol-mint-cursors
